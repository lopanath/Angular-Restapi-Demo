export class Student{
    studentId: number
    studenName: string
    studentAddress: string
    studentAge: number
    studenEmail: string
}