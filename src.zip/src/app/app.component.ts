import { Component, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import { CrudService } from './service/crud.service';
import { Student } from './model/Student';
import { FormsModule, NgForm } from '@angular/forms';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet,FormsModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
allStudents:Student[]=[];

  title = 'restapi-demo';
  @ViewChild('studentForm') myStudentForm: NgForm;
 
  constructor(private serv: CrudService) {}
 
  onSubmit(students:Student) {
    console.log(students);
 
    this.serv.addStudent(students).subscribe({
      next: function(data) {
        console.log(data);
      },
      error: (err)=> alert(err.message),
      complete:() => alert('completed'),
    });
    
  }
  getStudentsData()
  {
    this.serv.getStudent().subscribe({next:(val)=>{this.allStudents=val;}

  });

  }

  ngOnIt():void{
   this.getStudentsData();
  }
}
