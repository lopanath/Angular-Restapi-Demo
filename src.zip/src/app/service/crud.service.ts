import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Student } from '../model/Student';

@Injectable({
  providedIn: 'root'
})
export class CrudService {

  constructor(private http:HttpClient) { }
    addStudent(val: Student)
    {
      const myHeader= new HttpHeaders({'authorization':'Bearer'})
      return this.http.post("http://localhost:8070/student/addStudent" , val, {headers: myHeader});
    }
    getStudent()
    {
     return this.http.get<Student[]>("http://localhost:8070/student/getStudents");
    }
}
